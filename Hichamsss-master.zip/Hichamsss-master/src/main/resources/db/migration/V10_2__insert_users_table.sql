INSERT INTO `users` (`id`, `login`, `password`, `firstname`, `lastname`, `email`, `langue`, `created_at`) VALUES
(1, 'bob', '', 'Bob', 'Sull', 'bob@sull.com','fr','2010-01-01 12:00:00'),
(2, 'lana', '', 'Lana', 'Sull', 'lana@sull.com','fr','2010-01-01 12:00:00'),
(3, 'affiliate', '', 'Affi', 'Liate', 'contact@affiliate.com','fr','2020-01-01 12:00:00');
