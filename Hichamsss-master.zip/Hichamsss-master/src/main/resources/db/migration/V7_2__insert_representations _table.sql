INSERT INTO `representations` (`id`, `show_id`, `location_id`, `when`) VALUES
(1, 1, 1, '2012-10-12 13:30'),
(2, 1, 2, '2012-10-12 20:30'),
(3, 2, NULL, '2012-10-02 20:30'),
(4, 3, NULL, '2012-10-16 20:30');
