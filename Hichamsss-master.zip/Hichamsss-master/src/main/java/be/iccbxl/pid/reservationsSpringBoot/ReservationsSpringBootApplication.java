package be.iccbxl.pid.reservationsSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationsSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationsSpringBootApplication.class, args);
	}

}
